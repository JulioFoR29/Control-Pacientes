# MedTrack — Sistema de Seguimiento de Pacientes

## Descripción
Aplicación web para consultorios médicos en español. Seguimiento de pacientes, medicamentos, asistencia y reportes mensuales exportables a Excel.

## Arquitectura

- **Frontend**: React + Vite (`artifacts/pacientes`, puerto dinámico via `PORT`)
- **Backend**: Express + PostgreSQL (`artifacts/api-server`, puerto 8080)
- **BD**: PostgreSQL via Drizzle ORM (`lib/db`)
- **API Contract**: OpenAPI spec en `lib/api-spec`, codegen con Orval
- **Cliente React**: hooks generados en `lib/api-client-react`

## Rutas del Frontend

| Ruta | Página |
|------|--------|
| `/` | Dashboard |
| `/patients` | Directorio de pacientes |
| `/patients/:id` | Expediente detallado del paciente |
| `/programas` | Gestión de tipos de programa |
| `/informes` | Informe mensual + exportación Excel |

## Rutas del Backend (`/api`)

| Método | Ruta | Descripción |
|--------|------|-------------|
| GET/POST | `/patients` | Listar / crear pacientes |
| GET/PUT/DELETE | `/patients/:id` | Obtener / actualizar / eliminar |
| GET | `/patients/summary` | Resumen estadístico |
| GET/POST | `/medications` | Listar / crear medicamentos |
| PUT/DELETE | `/medications/:id` | Actualizar / eliminar medicamento |
| GET/POST | `/attendance` | Listar / crear registros de asistencia |
| PUT/DELETE | `/attendance/:id` | Actualizar / eliminar registro |
| GET/POST | `/programs` | Listar / crear programas |
| PUT/DELETE | `/programs/:id` | Actualizar / eliminar programa |
| GET | `/reports/monthly` | Informe mensual (corte: día 25) |

## Sistema de Temas (5 temas)

Almacenado en `localStorage` con clave `app-theme`. Se aplica via `data-theme` en `<html>`.

| ID | Nombre |
|----|--------|
| `profesional` | Profesional (teal, default) |
| `pastel` | Pastel (morado suave) |
| `oscuro` | Oscuro (dark mode) |
| `verde` | Verde Salud (emerald) |
| `azul` | Azul Clínica (blue) |

## Funcionalidades principales

- Pacientes: CRUD completo con estado (activo / pendiente / alta), programa asignado, próxima cita
- Medicamentos: por paciente — nombre, dosis, frecuencia, fechas de inicio/fin, notas
- Asistencia: por paciente — fecha, asistió/no asistió, indicador visual amber para ausencias con "recordatorio pendiente"
- Programas: CRUD de tipos de programa personalizables (Diabetes, Hipertensión, etc.)
- Informe mensual: corte el día 25, totales por paciente, exportación a `.xlsx` con SheetJS

## Notas de desarrollo

- `lib/api-zod/src/index.ts` solo exporta `./generated/api` (no `./generated/types`) para evitar conflictos de nombres del codegen de Orval
- No usar `console.log` en el servidor — usar `req.log` en handlers y `logger` para código fuera de requests
- Los datos de pacientes son persistentes en PostgreSQL; nunca se pierden entre meses a menos que se eliminen manualmente
- Los programas predeterminados se siembran al iniciar: Diabetes, Hipertensión, Adulto Mayor, Salud Mental, Nutrición
