import { Router } from "express";
import { db, attendanceTable } from "@workspace/db";
import { eq, and, gte, lte } from "drizzle-orm";
import {
  ListAttendanceQueryParams,
  CreateAttendanceBody,
  UpdateAttendanceParams,
  UpdateAttendanceBody,
  DeleteAttendanceParams,
} from "@workspace/api-zod";

const router = Router();

router.get("/attendance", async (req, res) => {
  try {
    const { patientId, month, year } = ListAttendanceQueryParams.parse(req.query);
    let rows = await db.select().from(attendanceTable);
    if (patientId) rows = rows.filter((r) => r.patientId === patientId);
    if (month && year) {
      const cutoff = `${year}-${String(month).padStart(2, "0")}-25`;
      const start = `${year}-${String(month).padStart(2, "0")}-01`;
      rows = rows.filter((r) => r.appointmentDate >= start && r.appointmentDate <= cutoff);
    }
    res.json(rows.map((r) => ({ ...r, createdAt: r.createdAt.toISOString() })));
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Internal server error" });
  }
});

router.post("/attendance", async (req, res) => {
  try {
    const body = CreateAttendanceBody.parse(req.body);
    const [rec] = await db.insert(attendanceTable).values({
      patientId: body.patientId,
      appointmentDate: body.appointmentDate,
      attended: body.attended,
      contacted: body.contacted ?? false,
      notes: body.notes ?? null,
    }).returning();
    res.status(201).json({ ...rec, createdAt: rec.createdAt.toISOString() });
  } catch (err) {
    req.log.error(err);
    res.status(400).json({ error: "Invalid request" });
  }
});

router.put("/attendance/:id", async (req, res) => {
  try {
    const { id } = UpdateAttendanceParams.parse(req.params);
    const body = UpdateAttendanceBody.parse(req.body);
    const updates: Record<string, unknown> = {};
    if (body.appointmentDate !== undefined) updates.appointmentDate = body.appointmentDate;
    if (body.attended !== undefined) updates.attended = body.attended;
    if (body.contacted !== undefined) updates.contacted = body.contacted;
    if (body.notes !== undefined) updates.notes = body.notes;
    const [rec] = await db.update(attendanceTable).set(updates).where(eq(attendanceTable.id, id)).returning();
    if (!rec) return res.status(404).json({ error: "Not found" });
    res.json({ ...rec, createdAt: rec.createdAt.toISOString() });
  } catch (err) {
    req.log.error(err);
    res.status(400).json({ error: "Invalid request" });
  }
});

router.delete("/attendance/:id", async (req, res) => {
  try {
    const { id } = DeleteAttendanceParams.parse(req.params);
    await db.delete(attendanceTable).where(eq(attendanceTable.id, id));
    res.status(204).send();
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Internal server error" });
  }
});

export default router;
