import { Router } from "express";
import { db, patientsTable, attendanceTable, medicationsTable, programsTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { GetMonthlyReportQueryParams } from "@workspace/api-zod";

const router = Router();

router.get("/reports/monthly", async (req, res) => {
  try {
    const { year, month } = GetMonthlyReportQueryParams.parse(req.query);

    const cutoffDate = `${year}-${String(month).padStart(2, "0")}-25`;
    const startDate = `${year}-${String(month).padStart(2, "0")}-01`;

    const patients = await db.select().from(patientsTable);
    const programs = await db.select().from(programsTable);
    const allAttendance = await db.select().from(attendanceTable);
    const allMedications = await db.select().from(medicationsTable);

    const programMap = new Map(programs.map((p) => [p.id, p.name]));

    const periodAttendance = allAttendance.filter(
      (a) => a.appointmentDate >= startDate && a.appointmentDate <= cutoffDate
    );

    let totalAttendances = 0;
    let totalAbsences = 0;

    const reportPatients = patients.map((patient) => {
      const patientAttendance = periodAttendance.filter((a) => a.patientId === patient.id);
      const attendanceCount = patientAttendance.filter((a) => a.attended).length;
      const absenceCount = patientAttendance.filter((a) => !a.attended).length;
      totalAttendances += attendanceCount;
      totalAbsences += absenceCount;

      const patientMeds = allMedications
        .filter((m) => m.patientId === patient.id)
        .map((m) => `${m.name} ${m.dose} (${m.frequency})`);

      return {
        id: patient.id,
        name: patient.name,
        age: patient.age,
        diagnosis: patient.diagnosis,
        status: patient.status,
        programName: patient.programId ? (programMap.get(patient.programId) ?? null) : null,
        attendanceCount,
        absenceCount,
        medications: patientMeds,
      };
    });

    res.json({
      year,
      month,
      cutoffDate,
      totalPatients: patients.length,
      totalAttendances,
      totalAbsences,
      patients: reportPatients,
    });
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Internal server error" });
  }
});

export default router;
