import { Router } from "express";
import { db, medicationsTable } from "@workspace/db";
import { eq, and } from "drizzle-orm";
import {
  ListMedicationsQueryParams,
  CreateMedicationBody,
  UpdateMedicationParams,
  UpdateMedicationBody,
  DeleteMedicationParams,
} from "@workspace/api-zod";

const router = Router();

router.get("/medications", async (req, res) => {
  try {
    const { patientId } = ListMedicationsQueryParams.parse(req.query);
    const rows = patientId
      ? await db.select().from(medicationsTable).where(eq(medicationsTable.patientId, patientId))
      : await db.select().from(medicationsTable);
    res.json(rows.map((r) => ({ ...r, createdAt: r.createdAt.toISOString() })));
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Internal server error" });
  }
});

router.post("/medications", async (req, res) => {
  try {
    const body = CreateMedicationBody.parse(req.body);
    const [med] = await db.insert(medicationsTable).values({
      patientId: body.patientId,
      name: body.name,
      dose: body.dose,
      frequency: body.frequency,
      startDate: body.startDate ?? null,
      endDate: body.endDate ?? null,
      notes: body.notes ?? null,
    }).returning();
    res.status(201).json({ ...med, createdAt: med.createdAt.toISOString() });
  } catch (err) {
    req.log.error(err);
    res.status(400).json({ error: "Invalid request" });
  }
});

router.put("/medications/:id", async (req, res) => {
  try {
    const { id } = UpdateMedicationParams.parse(req.params);
    const body = UpdateMedicationBody.parse(req.body);
    const updates: Record<string, unknown> = {};
    if (body.name !== undefined) updates.name = body.name;
    if (body.dose !== undefined) updates.dose = body.dose;
    if (body.frequency !== undefined) updates.frequency = body.frequency;
    if (body.startDate !== undefined) updates.startDate = body.startDate;
    if (body.endDate !== undefined) updates.endDate = body.endDate;
    if (body.notes !== undefined) updates.notes = body.notes;
    const [med] = await db.update(medicationsTable).set(updates).where(eq(medicationsTable.id, id)).returning();
    if (!med) return res.status(404).json({ error: "Not found" });
    res.json({ ...med, createdAt: med.createdAt.toISOString() });
  } catch (err) {
    req.log.error(err);
    res.status(400).json({ error: "Invalid request" });
  }
});

router.delete("/medications/:id", async (req, res) => {
  try {
    const { id } = DeleteMedicationParams.parse(req.params);
    await db.delete(medicationsTable).where(eq(medicationsTable.id, id));
    res.status(204).send();
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Internal server error" });
  }
});

export default router;
