import { Router } from "express";
import { db, programsTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import {
  CreateProgramBody,
  UpdateProgramParams,
  UpdateProgramBody,
  DeleteProgramParams,
} from "@workspace/api-zod";

const router = Router();

router.get("/programs", async (req, res) => {
  try {
    const rows = await db.select().from(programsTable);
    res.json(rows.map((r) => ({ ...r, createdAt: r.createdAt.toISOString() })));
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Internal server error" });
  }
});

router.post("/programs", async (req, res) => {
  try {
    const body = CreateProgramBody.parse(req.body);
    const [prog] = await db.insert(programsTable).values({
      name: body.name,
      description: body.description ?? null,
    }).returning();
    res.status(201).json({ ...prog, createdAt: prog.createdAt.toISOString() });
  } catch (err) {
    req.log.error(err);
    res.status(400).json({ error: "Invalid request" });
  }
});

router.put("/programs/:id", async (req, res) => {
  try {
    const { id } = UpdateProgramParams.parse(req.params);
    const body = UpdateProgramBody.parse(req.body);
    const updates: Record<string, unknown> = {};
    if (body.name !== undefined) updates.name = body.name;
    if (body.description !== undefined) updates.description = body.description;
    const [prog] = await db.update(programsTable).set(updates).where(eq(programsTable.id, id)).returning();
    if (!prog) return res.status(404).json({ error: "Not found" });
    res.json({ ...prog, createdAt: prog.createdAt.toISOString() });
  } catch (err) {
    req.log.error(err);
    res.status(400).json({ error: "Invalid request" });
  }
});

router.delete("/programs/:id", async (req, res) => {
  try {
    const { id } = DeleteProgramParams.parse(req.params);
    await db.delete(programsTable).where(eq(programsTable.id, id));
    res.status(204).send();
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Internal server error" });
  }
});

export default router;
