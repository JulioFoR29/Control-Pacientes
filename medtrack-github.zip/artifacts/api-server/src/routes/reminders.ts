import { Router } from "express";
import { db, attendanceTable } from "@workspace/db";
import { patientsTable } from "@workspace/db";
import { programsTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { MarkContactedParams } from "@workspace/api-zod";

const router = Router();

router.get("/reminders", async (req, res) => {
  try {
    const rows = await db
      .select({
        attendanceId: attendanceTable.id,
        patientId: attendanceTable.patientId,
        patientName: patientsTable.name,
        diagnosis: patientsTable.diagnosis,
        programName: programsTable.name,
        appointmentDate: attendanceTable.appointmentDate,
        notes: attendanceTable.notes,
        contacted: attendanceTable.contacted,
      })
      .from(attendanceTable)
      .innerJoin(patientsTable, eq(attendanceTable.patientId, patientsTable.id))
      .leftJoin(programsTable, eq(patientsTable.programId, programsTable.id))
      .where(eq(attendanceTable.attended, false));

    res.json(rows);
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Internal server error" });
  }
});

router.patch("/reminders/:attendanceId/contacted", async (req, res) => {
  try {
    const { attendanceId } = MarkContactedParams.parse(req.params);

    const [updated] = await db
      .update(attendanceTable)
      .set({ contacted: true })
      .where(eq(attendanceTable.id, attendanceId))
      .returning();

    if (!updated) return res.status(404).json({ error: "Not found" });

    const [row] = await db
      .select({
        attendanceId: attendanceTable.id,
        patientId: attendanceTable.patientId,
        patientName: patientsTable.name,
        diagnosis: patientsTable.diagnosis,
        programName: programsTable.name,
        appointmentDate: attendanceTable.appointmentDate,
        notes: attendanceTable.notes,
        contacted: attendanceTable.contacted,
      })
      .from(attendanceTable)
      .innerJoin(patientsTable, eq(attendanceTable.patientId, patientsTable.id))
      .leftJoin(programsTable, eq(patientsTable.programId, programsTable.id))
      .where(eq(attendanceTable.id, attendanceId));

    res.json(row);
  } catch (err) {
    req.log.error(err);
    res.status(400).json({ error: "Invalid request" });
  }
});

export default router;
