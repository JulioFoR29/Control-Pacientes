import { Router, type IRouter } from "express";
import healthRouter from "./health";
import patientsRouter from "./patients";
import medicationsRouter from "./medications";
import programsRouter from "./programs";
import attendanceRouter from "./attendance";
import remindersRouter from "./reminders";
import reportsRouter from "./reports";

const router: IRouter = Router();

router.use(healthRouter);
router.use(patientsRouter);
router.use(medicationsRouter);
router.use(programsRouter);
router.use(attendanceRouter);
router.use(remindersRouter);
router.use(reportsRouter);

export default router;
