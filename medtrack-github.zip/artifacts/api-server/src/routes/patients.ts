import { Router } from "express";
import { db, patientsTable } from "@workspace/db";
import { eq, desc } from "drizzle-orm";
import {
  CreatePatientBody,
  UpdatePatientBody,
  GetPatientParams,
  UpdatePatientParams,
  DeletePatientParams,
} from "@workspace/api-zod";

const router = Router();

router.get("/patients/summary", async (req, res) => {
  try {
    const all = await db.select().from(patientsTable).orderBy(desc(patientsTable.createdAt));
    const active = all.filter((p) => p.status === "active").length;
    const discharged = all.filter((p) => p.status === "discharged").length;
    const pending = all.filter((p) => p.status === "pending").length;
    const recentlyAdded = all.slice(0, 5).map((p) => ({
      ...p,
      createdAt: p.createdAt.toISOString(),
      updatedAt: p.updatedAt.toISOString(),
    }));
    res.json({ total: all.length, active, discharged, pending, recentlyAdded });
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Internal server error" });
  }
});

router.get("/patients", async (req, res) => {
  try {
    const patients = await db.select().from(patientsTable).orderBy(desc(patientsTable.createdAt));
    res.json(
      patients.map((p) => ({
        ...p,
        createdAt: p.createdAt.toISOString(),
        updatedAt: p.updatedAt.toISOString(),
      }))
    );
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Internal server error" });
  }
});

router.post("/patients", async (req, res) => {
  try {
    const body = CreatePatientBody.parse(req.body);
    const [patient] = await db
      .insert(patientsTable)
      .values({
        name: body.name,
        age: body.age,
        diagnosis: body.diagnosis,
        notes: body.notes ?? null,
        nextAppointment: body.nextAppointment ?? null,
        status: body.status,
      })
      .returning();
    res.status(201).json({
      ...patient,
      createdAt: patient.createdAt.toISOString(),
      updatedAt: patient.updatedAt.toISOString(),
    });
  } catch (err) {
    req.log.error(err);
    res.status(400).json({ error: "Invalid request" });
  }
});

router.get("/patients/:id", async (req, res) => {
  try {
    const { id } = GetPatientParams.parse(req.params);
    const [patient] = await db.select().from(patientsTable).where(eq(patientsTable.id, id));
    if (!patient) {
      return res.status(404).json({ error: "Patient not found" });
    }
    res.json({
      ...patient,
      createdAt: patient.createdAt.toISOString(),
      updatedAt: patient.updatedAt.toISOString(),
    });
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Internal server error" });
  }
});

router.put("/patients/:id", async (req, res) => {
  try {
    const { id } = UpdatePatientParams.parse(req.params);
    const body = UpdatePatientBody.parse(req.body);
    const updates: Record<string, unknown> = { updatedAt: new Date() };
    if (body.name !== undefined) updates.name = body.name;
    if (body.age !== undefined) updates.age = body.age;
    if (body.diagnosis !== undefined) updates.diagnosis = body.diagnosis;
    if (body.notes !== undefined) updates.notes = body.notes;
    if (body.nextAppointment !== undefined) updates.nextAppointment = body.nextAppointment;
    if (body.status !== undefined) updates.status = body.status;

    const [patient] = await db
      .update(patientsTable)
      .set(updates)
      .where(eq(patientsTable.id, id))
      .returning();

    if (!patient) {
      return res.status(404).json({ error: "Patient not found" });
    }
    res.json({
      ...patient,
      createdAt: patient.createdAt.toISOString(),
      updatedAt: patient.updatedAt.toISOString(),
    });
  } catch (err) {
    req.log.error(err);
    res.status(400).json({ error: "Invalid request" });
  }
});

router.delete("/patients/:id", async (req, res) => {
  try {
    const { id } = DeletePatientParams.parse(req.params);
    const [deleted] = await db.delete(patientsTable).where(eq(patientsTable.id, id)).returning();
    if (!deleted) {
      return res.status(404).json({ error: "Patient not found" });
    }
    res.status(204).send();
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Internal server error" });
  }
});

export default router;
