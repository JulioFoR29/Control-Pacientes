import { Badge } from "@/components/ui/badge";
import { PatientStatus } from "@workspace/api-client-react";
import { CheckCircle2, Clock, CheckCircle } from "lucide-react";

export function StatusBadge({ status }: { status: PatientStatus }) {
  if (status === "active") {
    return (
      <Badge variant="default" className="bg-primary/10 text-primary hover:bg-primary/20 border-primary/20 gap-1.5 shadow-none font-medium">
        <CheckCircle2 className="w-3.5 h-3.5" />
        Activo
      </Badge>
    );
  }
  
  if (status === "pending") {
    return (
      <Badge variant="outline" className="bg-amber-50 text-amber-700 hover:bg-amber-100 border-amber-200 dark:bg-amber-950/30 dark:text-amber-400 gap-1.5 shadow-none font-medium">
        <Clock className="w-3.5 h-3.5" />
        Pendiente
      </Badge>
    );
  }

  return (
    <Badge variant="secondary" className="bg-emerald-50 text-emerald-700 hover:bg-emerald-100 border-emerald-200 dark:bg-emerald-950/30 dark:text-emerald-400 gap-1.5 shadow-none font-medium">
      <CheckCircle className="w-3.5 h-3.5" />
      Alta
    </Badge>
  );
}
