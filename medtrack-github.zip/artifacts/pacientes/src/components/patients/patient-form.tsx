import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Patient, NewPatient, useListPrograms } from "@workspace/api-client-react";
import { useEffect } from "react";

const patientSchema = z.object({
  name: z.string().min(2, "El nombre es requerido"),
  age: z.coerce.number().min(0, "La edad debe ser mayor a 0").max(150, "Edad no válida"),
  diagnosis: z.string().min(2, "El diagnóstico es requerido"),
  notes: z.string().optional(),
  nextAppointment: z.string().optional().nullable(),
  status: z.enum(["active", "pending", "discharged"]),
  programId: z.coerce.number().optional().nullable(),
});

type PatientFormValues = z.infer<typeof patientSchema>;

export function PatientForm({
  initialData,
  onSubmit,
  isLoading,
}: {
  initialData?: Patient;
  onSubmit: (data: NewPatient) => void;
  isLoading?: boolean;
}) {
  const { data: programs = [] } = useListPrograms();

  const form = useForm<PatientFormValues>({
    resolver: zodResolver(patientSchema),
    defaultValues: {
      name: initialData?.name || "",
      age: initialData?.age || 0,
      diagnosis: initialData?.diagnosis || "",
      notes: initialData?.notes || "",
      nextAppointment: initialData?.nextAppointment || "",
      status: initialData?.status || "pending",
      programId: initialData?.programId ?? null,
    },
  });

  useEffect(() => {
    if (initialData) {
      form.reset({
        name: initialData.name,
        age: initialData.age,
        diagnosis: initialData.diagnosis,
        notes: initialData.notes || "",
        nextAppointment: initialData.nextAppointment || "",
        status: initialData.status,
        programId: initialData.programId ?? null,
      });
    }
  }, [initialData, form]);

  const handleSubmit = (data: PatientFormValues) => {
    onSubmit(data as NewPatient);
  };

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <FormField
            control={form.control}
            name="name"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Nombre Completo</FormLabel>
                <FormControl>
                  <Input placeholder="Ej. María García" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="age"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Edad</FormLabel>
                <FormControl>
                  <Input type="number" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="diagnosis"
            render={({ field }) => (
              <FormItem className="md:col-span-2">
                <FormLabel>Diagnóstico</FormLabel>
                <FormControl>
                  <Input placeholder="Diagnóstico principal" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="status"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Estado</FormLabel>
                <Select onValueChange={field.onChange} value={field.value}>
                  <FormControl>
                    <SelectTrigger>
                      <SelectValue placeholder="Seleccionar estado" />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    <SelectItem value="active">Activo</SelectItem>
                    <SelectItem value="pending">Pendiente</SelectItem>
                    <SelectItem value="discharged">Alta</SelectItem>
                  </SelectContent>
                </Select>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="programId"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Programa (Opcional)</FormLabel>
                <Select
                  onValueChange={(v) => field.onChange(v === "none" ? null : Number(v))}
                  value={field.value ? String(field.value) : "none"}
                >
                  <FormControl>
                    <SelectTrigger>
                      <SelectValue placeholder="Seleccionar programa" />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    <SelectItem value="none">Sin programa</SelectItem>
                    {programs.map((p) => (
                      <SelectItem key={p.id} value={String(p.id)}>
                        {p.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="nextAppointment"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Próxima Cita (Opcional)</FormLabel>
                <FormControl>
                  <Input type="date" {...field} value={field.value || ""} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="notes"
            render={({ field }) => (
              <FormItem className="md:col-span-2">
                <FormLabel>Notas (Opcional)</FormLabel>
                <FormControl>
                  <Textarea
                    placeholder="Observaciones adicionales..."
                    className="resize-none h-24"
                    {...field}
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>

        <div className="flex justify-end gap-3 pt-4 border-t">
          <Button type="submit" disabled={isLoading} className="w-full sm:w-auto min-w-[120px]">
            {isLoading ? "Guardando..." : "Guardar Paciente"}
          </Button>
        </div>
      </form>
    </Form>
  );
}
