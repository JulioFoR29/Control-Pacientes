import { Link, useLocation } from "wouter";
import { Activity, Users, Home, ClipboardList, FileBarChart, Palette, Moon, Sun } from "lucide-react";
import { useTheme } from "@/lib/theme-provider";
import { Button } from "@/components/ui/button";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";

const themeConfig = [
  { id: "profesional", label: "Profesional", color: "bg-teal-700" },
  { id: "pastel", label: "Pastel", color: "bg-purple-200" },
  { id: "oscuro", label: "Oscuro", color: "bg-slate-900" },
  { id: "verde", label: "Verde Salud", color: "bg-emerald-600" },
  { id: "azul", label: "Azul Clínica", color: "bg-blue-600" },
] as const;

export function Layout({ children }: { children: React.ReactNode }) {
  const [location] = useLocation();
  const { theme, setTheme } = useTheme();

  return (
    <div className="min-h-[100dvh] flex flex-col w-full">
      <header className="sticky top-0 z-40 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 shadow-sm">
        <div className="container mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-6">
            <Link href="/" className="flex items-center gap-2 group">
              <div className="w-8 h-8 rounded-lg bg-primary flex items-center justify-center text-primary-foreground shadow-sm group-hover:shadow-md transition-all">
                <Activity className="w-5 h-5" />
              </div>
              <span className="font-semibold text-lg tracking-tight hidden sm:inline-block">MedTrack</span>
            </Link>
            
            <nav className="hidden md:flex items-center gap-1">
              <Link href="/">
                <Button variant={location === "/" ? "secondary" : "ghost"} size="sm" className="gap-2">
                  <Home className="w-4 h-4" />
                  Inicio
                </Button>
              </Link>
              <Link href="/patients">
                <Button variant={location.startsWith("/patients") ? "secondary" : "ghost"} size="sm" className="gap-2">
                  <Users className="w-4 h-4" />
                  Pacientes
                </Button>
              </Link>
              <Link href="/programas">
                <Button variant={location.startsWith("/programas") ? "secondary" : "ghost"} size="sm" className="gap-2">
                  <ClipboardList className="w-4 h-4" />
                  Programas
                </Button>
              </Link>
              <Link href="/informes">
                <Button variant={location.startsWith("/informes") ? "secondary" : "ghost"} size="sm" className="gap-2">
                  <FileBarChart className="w-4 h-4" />
                  Informes
                </Button>
              </Link>
            </nav>
          </div>

          <div className="flex items-center gap-4">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" size="sm" className="gap-2 rounded-full shadow-sm transition-all">
                  <Palette className="w-4 h-4" />
                  <span className="hidden sm:inline">
                    {themeConfig.find(t => t.id === theme)?.label || "Tema"}
                  </span>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                {themeConfig.map((t) => (
                  <DropdownMenuItem 
                    key={t.id} 
                    onClick={() => setTheme(t.id as any)}
                    className="gap-2"
                  >
                    <div className={`w-3 h-3 rounded-full ${t.color}`} />
                    {t.label}
                  </DropdownMenuItem>
                ))}
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
      </header>

      {/* Mobile nav bottom bar */}
      <div className="md:hidden fixed bottom-0 left-0 right-0 z-40 border-t bg-background/95 backdrop-blur pb-safe">
        <div className="flex justify-around items-center h-16 px-2">
          <Link href="/" className={`flex flex-col items-center justify-center w-full h-full space-y-1 ${location === "/" ? "text-primary" : "text-muted-foreground"}`}>
            <Home className="w-5 h-5" />
            <span className="text-[10px] font-medium">Inicio</span>
          </Link>
          <Link href="/patients" className={`flex flex-col items-center justify-center w-full h-full space-y-1 ${location.startsWith("/patients") ? "text-primary" : "text-muted-foreground"}`}>
            <Users className="w-5 h-5" />
            <span className="text-[10px] font-medium">Pacientes</span>
          </Link>
          <Link href="/programas" className={`flex flex-col items-center justify-center w-full h-full space-y-1 ${location.startsWith("/programas") ? "text-primary" : "text-muted-foreground"}`}>
            <ClipboardList className="w-5 h-5" />
            <span className="text-[10px] font-medium">Programas</span>
          </Link>
          <Link href="/informes" className={`flex flex-col items-center justify-center w-full h-full space-y-1 ${location.startsWith("/informes") ? "text-primary" : "text-muted-foreground"}`}>
            <FileBarChart className="w-5 h-5" />
            <span className="text-[10px] font-medium">Informes</span>
          </Link>
        </div>
      </div>

      <main className="flex-1 container mx-auto px-4 py-8 pb-24 md:pb-8">
        {children}
      </main>
    </div>
  );
}
