import { Link } from "wouter";
import {
  useGetPatientsSummary,
  useListReminders,
  useMarkContacted,
  getGetPatientsSummaryQueryKey,
  getListRemindersQueryKey,
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { StatusBadge } from "@/components/ui/status-badge";
import { useToast } from "@/hooks/use-toast";
import {
  Users,
  UserPlus,
  Activity,
  Clock,
  CheckCircle,
  ArrowRight,
  Calendar,
  Bell,
  BellOff,
  PhoneCall,
} from "lucide-react";
import { format } from "date-fns";
import { es } from "date-fns/locale";

export default function DashboardPage() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const { data: summary, isLoading, isError } = useGetPatientsSummary({
    query: { queryKey: getGetPatientsSummaryQueryKey() },
  });

  const { data: reminders = [] } = useListReminders({
    query: { queryKey: getListRemindersQueryKey() },
  });

  const markContacted = useMarkContacted();

  const pendingReminders = reminders.filter((r) => !r.contacted);
  const contactedToday = reminders.filter((r) => r.contacted);

  const handleMarkContacted = (attendanceId: number, patientName: string) => {
    markContacted.mutate(
      { attendanceId },
      {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: getListRemindersQueryKey() });
          toast({
            title: "Contacto registrado",
            description: `${patientName} marcado como contactado.`,
          });
        },
        onError: () => toast({ title: "Error al registrar contacto.", variant: "destructive" }),
      }
    );
  };

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div className="space-y-1">
            <div className="h-8 w-48 bg-muted animate-pulse rounded" />
            <div className="h-4 w-64 bg-muted animate-pulse rounded" />
          </div>
        </div>
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          {[1, 2, 3, 4].map((i) => (
            <Card key={i} className="animate-pulse">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <div className="h-4 w-20 bg-muted rounded" />
              </CardHeader>
              <CardContent>
                <div className="h-8 w-12 bg-muted rounded mb-1" />
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  if (isError || !summary) {
    return (
      <div className="flex flex-col items-center justify-center h-[50vh] text-center">
        <Activity className="h-12 w-12 text-destructive mb-4 opacity-50" />
        <h2 className="text-xl font-semibold mb-2">Error al cargar datos</h2>
        <p className="text-muted-foreground max-w-md">
          Hubo un problema al cargar el resumen del sistema. Por favor, intente nuevamente.
        </p>
      </div>
    );
  }

  const statCards = [
    {
      title: "Total Pacientes",
      value: summary.total,
      icon: Users,
      color: "text-primary",
      bg: "bg-primary/10",
    },
    {
      title: "Activos",
      value: summary.active,
      icon: Activity,
      color: "text-blue-600 dark:text-blue-400",
      bg: "bg-blue-100 dark:bg-blue-900/30",
    },
    {
      title: "Pendientes",
      value: summary.pending,
      icon: Clock,
      color: "text-amber-600 dark:text-amber-400",
      bg: "bg-amber-100 dark:bg-amber-900/30",
    },
    {
      title: "Dados de Alta",
      value: summary.discharged,
      icon: CheckCircle,
      color: "text-emerald-600 dark:text-emerald-400",
      bg: "bg-emerald-100 dark:bg-emerald-900/30",
    },
  ];

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Panel de Control</h1>
          <p className="text-muted-foreground mt-1">
            Resumen del estado actual de los pacientes en la clínica.
          </p>
        </div>
        <Link href="/patients">
          <Button className="gap-2 shadow-md hover:shadow-lg transition-all">
            <UserPlus className="w-4 h-4" />
            Nuevo Paciente
          </Button>
        </Link>
      </div>

      {/* Stats */}
      <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
        {statCards.map((stat, index) => {
          const Icon = stat.icon;
          return (
            <Card key={index} className="border-none shadow-sm hover:shadow-md transition-all duration-300">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground">
                  {stat.title}
                </CardTitle>
                <div className={`p-2 rounded-full ${stat.bg}`}>
                  <Icon className={`h-4 w-4 ${stat.color}`} />
                </div>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold">{stat.value}</div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Reminders Panel */}
      <Card className={`shadow-sm border-l-4 ${pendingReminders.length > 0 ? "border-l-amber-500" : "border-l-emerald-500"}`}>
        <CardHeader className="flex flex-row items-center justify-between pb-4">
          <div className="flex items-center gap-3">
            <div className={`p-2 rounded-full ${pendingReminders.length > 0 ? "bg-amber-100" : "bg-emerald-100"}`}>
              {pendingReminders.length > 0
                ? <Bell className="w-5 h-5 text-amber-600" />
                : <BellOff className="w-5 h-5 text-emerald-600" />
              }
            </div>
            <div>
              <CardTitle className="text-base">
                Recordatorios de Ausencias
                {pendingReminders.length > 0 && (
                  <Badge className="ml-2 bg-amber-500 hover:bg-amber-500 text-white text-xs">
                    {pendingReminders.length} pendiente{pendingReminders.length !== 1 ? "s" : ""}
                  </Badge>
                )}
              </CardTitle>
              <CardDescription className="text-xs mt-0.5">
                Pacientes que no asistieron y aun no han sido contactados
              </CardDescription>
            </div>
          </div>
          {contactedToday.length > 0 && (
            <span className="text-xs text-muted-foreground hidden sm:block">
              {contactedToday.length} ya contactado{contactedToday.length !== 1 ? "s" : ""}
            </span>
          )}
        </CardHeader>
        <CardContent>
          {pendingReminders.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-6 text-center text-muted-foreground">
              <BellOff className="w-8 h-8 opacity-20 mb-2" />
              <p className="text-sm font-medium">Sin recordatorios pendientes</p>
              <p className="text-xs mt-1 opacity-70">Todos los pacientes ausentes han sido contactados.</p>
            </div>
          ) : (
            <div className="space-y-2">
              {pendingReminders.map((reminder) => (
                <div
                  key={reminder.attendanceId}
                  className="flex items-center justify-between gap-3 p-3 rounded-lg border border-amber-200 bg-amber-50/60 dark:bg-amber-900/10 dark:border-amber-800 hover:bg-amber-50 transition-colors"
                >
                  <div className="flex items-start gap-3 min-w-0">
                    <div className="w-8 h-8 rounded-full bg-amber-200 flex items-center justify-center flex-shrink-0 mt-0.5">
                      <PhoneCall className="w-4 h-4 text-amber-700" />
                    </div>
                    <div className="min-w-0">
                      <Link href={`/patients/${reminder.patientId}`}>
                        <p className="font-semibold text-sm truncate hover:text-primary transition-colors cursor-pointer">
                          {reminder.patientName}
                        </p>
                      </Link>
                      <p className="text-xs text-muted-foreground truncate">{reminder.diagnosis}</p>
                      <div className="flex items-center gap-2 mt-1 flex-wrap">
                        <span className="text-xs text-amber-700 font-medium">
                          Ausente: {reminder.appointmentDate}
                        </span>
                        {reminder.programName && (
                          <Badge variant="outline" className="text-xs h-4 px-1 py-0 border-amber-300 text-amber-700">
                            {reminder.programName}
                          </Badge>
                        )}
                        {reminder.notes && (
                          <span className="text-xs text-muted-foreground italic truncate max-w-[150px]">
                            {reminder.notes}
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                  <Button
                    size="sm"
                    variant="outline"
                    className="flex-shrink-0 gap-1.5 border-amber-300 hover:bg-amber-100 hover:border-amber-400 text-amber-800 text-xs h-8"
                    onClick={() => handleMarkContacted(reminder.attendanceId, reminder.patientName)}
                    disabled={markContacted.isPending}
                  >
                    <PhoneCall className="w-3 h-3" />
                    Contactado
                  </Button>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Bottom grid */}
      <div className="grid gap-6 md:grid-cols-2">
        <Card className="col-span-1 shadow-sm border-none">
          <CardHeader className="flex flex-row items-center justify-between">
            <div>
              <CardTitle>Añadidos Recientemente</CardTitle>
              <CardDescription>Ultimos pacientes registrados en el sistema</CardDescription>
            </div>
            <Link href="/patients">
              <Button variant="ghost" size="icon" className="text-muted-foreground">
                <ArrowRight className="h-4 w-4" />
              </Button>
            </Link>
          </CardHeader>
          <CardContent>
            {summary.recentlyAdded.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                <Users className="h-10 w-10 mx-auto mb-3 opacity-20" />
                <p>No hay pacientes recientes</p>
              </div>
            ) : (
              <div className="space-y-4">
                {summary.recentlyAdded.map((patient) => (
                  <Link
                    key={patient.id}
                    href={`/patients/${patient.id}`}
                    className="flex items-center justify-between p-3 rounded-xl hover:bg-muted/50 transition-colors group"
                  >
                    <div className="flex flex-col min-w-0">
                      <span className="font-medium group-hover:text-primary transition-colors truncate">
                        {patient.name}
                      </span>
                      <span className="text-sm text-muted-foreground line-clamp-1">
                        {patient.diagnosis}
                      </span>
                    </div>
                    <div className="flex items-center gap-3 flex-shrink-0">
                      <StatusBadge status={patient.status} />
                    </div>
                  </Link>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        <Card className="col-span-1 shadow-sm border-none bg-gradient-to-br from-primary/5 to-transparent">
          <CardHeader>
            <CardTitle>Proximas Citas</CardTitle>
            <CardDescription>Pacientes con citas programadas proximamente</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {summary.recentlyAdded
                .filter((p) => p.nextAppointment)
                .sort((a, b) => new Date(a.nextAppointment!).getTime() - new Date(b.nextAppointment!).getTime())
                .slice(0, 4)
                .map((patient) => (
                  <Link
                    key={patient.id}
                    href={`/patients/${patient.id}`}
                    className="flex items-start gap-4 p-3 rounded-xl bg-card border shadow-sm hover:shadow-md transition-all group"
                  >
                    <div className="mt-0.5 p-2 bg-primary/10 rounded-lg text-primary">
                      <Calendar className="h-4 w-4" />
                    </div>
                    <div>
                      <div className="font-medium group-hover:text-primary transition-colors">
                        {patient.name}
                      </div>
                      <div className="text-sm text-muted-foreground">
                        {format(new Date(patient.nextAppointment!), "EEEE d 'de' MMMM", { locale: es })}
                      </div>
                    </div>
                  </Link>
                ))}

              {summary.recentlyAdded.filter((p) => p.nextAppointment).length === 0 && (
                <div className="text-center py-8 text-muted-foreground">
                  <Calendar className="h-10 w-10 mx-auto mb-3 opacity-20" />
                  <p>No hay citas programadas proximamente</p>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
