import { useState, useMemo } from "react";
import { Link } from "wouter";
import { 
  useListPatients,
  useCreatePatient,
  getListPatientsQueryKey,
  getGetPatientsSummaryQueryKey
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { 
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { PatientForm } from "@/components/patients/patient-form";
import { StatusBadge } from "@/components/ui/status-badge";
import { useToast } from "@/hooks/use-toast";
import { Search, UserPlus, Filter, FileText, ChevronRight } from "lucide-react";
import { format } from "date-fns";
import { es } from "date-fns/locale";

export default function PatientsPage() {
  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: patients, isLoading } = useListPatients({
    query: {
      queryKey: getListPatientsQueryKey()
    }
  });

  const createPatient = useCreatePatient();

  const filteredPatients = useMemo(() => {
    if (!patients) return [];
    
    return patients.filter((patient) => {
      const matchesSearch = 
        patient.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        patient.diagnosis.toLowerCase().includes(searchQuery.toLowerCase());
        
      const matchesStatus = statusFilter === "all" || patient.status === statusFilter;
      
      return matchesSearch && matchesStatus;
    });
  }, [patients, searchQuery, statusFilter]);

  const handleCreatePatient = (data: any) => {
    createPatient.mutate({ data }, {
      onSuccess: () => {
        setIsCreateOpen(false);
        toast({
          title: "Paciente creado",
          description: "El paciente ha sido registrado exitosamente.",
        });
        // Invalidate lists and summaries
        queryClient.invalidateQueries({ queryKey: getListPatientsQueryKey() });
        queryClient.invalidateQueries({ queryKey: getGetPatientsSummaryQueryKey() });
      },
      onError: () => {
        toast({
          title: "Error",
          description: "Hubo un problema al crear el paciente. Intente nuevamente.",
          variant: "destructive",
        });
      }
    });
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-500">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Directorio de Pacientes</h1>
          <p className="text-muted-foreground mt-1">
            Gestione el registro completo de pacientes y sus historiales.
          </p>
        </div>

        <Dialog open={isCreateOpen} onOpenChange={setIsCreateOpen}>
          <DialogTrigger asChild>
            <Button className="gap-2 shadow-md">
              <UserPlus className="w-4 h-4" />
              Nuevo Paciente
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[600px]">
            <DialogHeader>
              <DialogTitle>Registrar Nuevo Paciente</DialogTitle>
              <DialogDescription>
                Ingrese la información inicial del paciente para abrir su expediente.
              </DialogDescription>
            </DialogHeader>
            <PatientForm 
              onSubmit={handleCreatePatient} 
              isLoading={createPatient.isPending}
            />
          </DialogContent>
        </Dialog>
      </div>

      <div className="flex flex-col sm:flex-row gap-4 bg-card p-4 rounded-xl shadow-sm border border-border/50">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input 
            placeholder="Buscar por nombre o diagnóstico..." 
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-9 bg-background/50"
          />
        </div>
        <div className="flex items-center gap-2 sm:w-auto w-full">
          <Filter className="h-4 w-4 text-muted-foreground ml-1" />
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-full sm:w-[180px] bg-background/50">
              <SelectValue placeholder="Estado" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Todos los estados</SelectItem>
              <SelectItem value="active">Activos</SelectItem>
              <SelectItem value="pending">Pendientes</SelectItem>
              <SelectItem value="discharged">Alta</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {isLoading ? (
        <div className="space-y-3">
          {[1, 2, 3, 4, 5].map((i) => (
            <div key={i} className="h-20 bg-muted animate-pulse rounded-xl" />
          ))}
        </div>
      ) : filteredPatients.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-20 text-center bg-card rounded-xl border border-dashed">
          <div className="h-16 w-16 bg-muted/50 rounded-full flex items-center justify-center mb-4">
            <FileText className="h-8 w-8 text-muted-foreground opacity-50" />
          </div>
          <h3 className="text-lg font-medium mb-1">No se encontraron pacientes</h3>
          <p className="text-muted-foreground max-w-sm mb-6">
            {searchQuery || statusFilter !== "all" 
              ? "Pruebe ajustando los filtros de búsqueda para ver más resultados."
              : "Aún no hay pacientes registrados en el sistema. Añada el primer paciente para comenzar."}
          </p>
          {(!searchQuery && statusFilter === "all") && (
            <Button onClick={() => setIsCreateOpen(true)} variant="outline" className="gap-2">
              <UserPlus className="w-4 h-4" />
              Registrar Primer Paciente
            </Button>
          )}
        </div>
      ) : (
        <div className="bg-card rounded-xl shadow-sm border overflow-hidden">
          <div className="grid gap-0 divide-y">
            {filteredPatients.map((patient) => (
              <Link 
                key={patient.id} 
                href={`/patients/${patient.id}`}
                className="group flex flex-col sm:flex-row sm:items-center justify-between p-4 sm:p-5 hover:bg-muted/30 transition-colors"
              >
                <div className="space-y-1 mb-3 sm:mb-0">
                  <div className="flex items-center gap-3">
                    <span className="font-semibold text-lg group-hover:text-primary transition-colors">
                      {patient.name}
                    </span>
                    <span className="text-sm text-muted-foreground bg-muted px-2 py-0.5 rounded-full">
                      {patient.age} años
                    </span>
                  </div>
                  <p className="text-muted-foreground text-sm flex items-center gap-2">
                    <span className="font-medium text-foreground/80">Dx:</span> {patient.diagnosis}
                  </p>
                </div>
                
                <div className="flex items-center justify-between sm:justify-end gap-6">
                  {patient.nextAppointment && (
                    <div className="text-sm text-right hidden md:block">
                      <div className="text-muted-foreground text-xs font-medium uppercase tracking-wider mb-0.5">
                        Próxima Cita
                      </div>
                      <div className="text-foreground">
                        {format(new Date(patient.nextAppointment), "d MMM, yyyy", { locale: es })}
                      </div>
                    </div>
                  )}
                  
                  <StatusBadge status={patient.status} />
                  
                  <div className="h-8 w-8 rounded-full bg-background flex items-center justify-center border shadow-sm group-hover:bg-primary group-hover:text-primary-foreground group-hover:border-primary transition-all">
                    <ChevronRight className="w-4 h-4" />
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
