import { useState } from "react";
import { useRoute, Link, useLocation } from "wouter";
import {
  useGetPatient,
  useUpdatePatient,
  useDeletePatient,
  useListMedications,
  useCreateMedication,
  useUpdateMedication,
  useDeleteMedication,
  useListAttendance,
  useCreateAttendance,
  useUpdateAttendance,
  useDeleteAttendance,
  useListPrograms,
  getGetPatientQueryKey,
  getListPatientsQueryKey,
  getGetPatientsSummaryQueryKey,
  getListMedicationsQueryKey,
  getListAttendanceQueryKey,
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogClose,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { PatientForm } from "@/components/patients/patient-form";
import { StatusBadge } from "@/components/ui/status-badge";
import { useToast } from "@/hooks/use-toast";
import {
  ArrowLeft,
  Edit3,
  Trash2,
  Calendar,
  Clock,
  User,
  FileText,
  Activity,
  Pill,
  Plus,
  Pencil,
  CheckCircle2,
  XCircle,
  ClipboardList,
} from "lucide-react";
import { format } from "date-fns";
import { es } from "date-fns/locale";
import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";

// ─── Medication Form ──────────────────────────────────────────────────────────
const medSchema = z.object({
  name: z.string().min(1, "Requerido"),
  dose: z.string().min(1, "Requerido"),
  frequency: z.string().min(1, "Requerido"),
  startDate: z.string().optional().nullable(),
  endDate: z.string().optional().nullable(),
  notes: z.string().optional().nullable(),
});
type MedFormValues = z.infer<typeof medSchema>;

function MedicationForm({
  initialData,
  onSubmit,
  isLoading,
}: {
  initialData?: MedFormValues;
  onSubmit: (data: MedFormValues) => void;
  isLoading?: boolean;
}) {
  const form = useForm<MedFormValues>({
    resolver: zodResolver(medSchema),
    defaultValues: initialData || { name: "", dose: "", frequency: "", startDate: "", endDate: "", notes: "" },
  });
  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <FormField control={form.control} name="name" render={({ field }) => (
            <FormItem className="sm:col-span-2">
              <FormLabel>Medicamento</FormLabel>
              <FormControl><Input placeholder="Ej. Metformina" {...field} /></FormControl>
              <FormMessage />
            </FormItem>
          )} />
          <FormField control={form.control} name="dose" render={({ field }) => (
            <FormItem>
              <FormLabel>Dosis</FormLabel>
              <FormControl><Input placeholder="Ej. 500mg" {...field} /></FormControl>
              <FormMessage />
            </FormItem>
          )} />
          <FormField control={form.control} name="frequency" render={({ field }) => (
            <FormItem>
              <FormLabel>Frecuencia</FormLabel>
              <FormControl><Input placeholder="Ej. Cada 8 horas" {...field} /></FormControl>
              <FormMessage />
            </FormItem>
          )} />
          <FormField control={form.control} name="startDate" render={({ field }) => (
            <FormItem>
              <FormLabel>Fecha inicio (Opcional)</FormLabel>
              <FormControl><Input type="date" {...field} value={field.value || ""} /></FormControl>
            </FormItem>
          )} />
          <FormField control={form.control} name="endDate" render={({ field }) => (
            <FormItem>
              <FormLabel>Fecha fin (Opcional)</FormLabel>
              <FormControl><Input type="date" {...field} value={field.value || ""} /></FormControl>
            </FormItem>
          )} />
          <FormField control={form.control} name="notes" render={({ field }) => (
            <FormItem className="sm:col-span-2">
              <FormLabel>Notas (Opcional)</FormLabel>
              <FormControl><Textarea className="resize-none h-16" {...field} value={field.value || ""} /></FormControl>
            </FormItem>
          )} />
        </div>
        <DialogFooter>
          <DialogClose asChild><Button type="button" variant="outline">Cancelar</Button></DialogClose>
          <Button type="submit" disabled={isLoading}>{isLoading ? "Guardando..." : "Guardar"}</Button>
        </DialogFooter>
      </form>
    </Form>
  );
}

// ─── Attendance Form ──────────────────────────────────────────────────────────
const attendSchema = z.object({
  appointmentDate: z.string().min(1, "Requerido"),
  attended: z.boolean(),
  notes: z.string().optional().nullable(),
});
type AttendFormValues = z.infer<typeof attendSchema>;

function AttendanceForm({
  initialData,
  onSubmit,
  isLoading,
}: {
  initialData?: AttendFormValues;
  onSubmit: (data: AttendFormValues) => void;
  isLoading?: boolean;
}) {
  const form = useForm<AttendFormValues>({
    resolver: zodResolver(attendSchema),
    defaultValues: initialData || { appointmentDate: "", attended: true, notes: "" },
  });
  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
        <FormField control={form.control} name="appointmentDate" render={({ field }) => (
          <FormItem>
            <FormLabel>Fecha de Cita</FormLabel>
            <FormControl><Input type="date" {...field} /></FormControl>
            <FormMessage />
          </FormItem>
        )} />
        <FormField control={form.control} name="attended" render={({ field }) => (
          <FormItem>
            <FormLabel>Asistencia</FormLabel>
            <div className="flex items-center gap-3 mt-1">
              <Switch
                checked={field.value}
                onCheckedChange={field.onChange}
                id="attended-switch"
              />
              <Label htmlFor="attended-switch" className={field.value ? "text-emerald-600 font-medium" : "text-amber-600 font-medium"}>
                {field.value ? "Asistio" : "No asistio"}
              </Label>
            </div>
          </FormItem>
        )} />
        <FormField control={form.control} name="notes" render={({ field }) => (
          <FormItem>
            <FormLabel>Notas (Opcional)</FormLabel>
            <FormControl><Textarea className="resize-none h-16" {...field} value={field.value || ""} /></FormControl>
          </FormItem>
        )} />
        <DialogFooter>
          <DialogClose asChild><Button type="button" variant="outline">Cancelar</Button></DialogClose>
          <Button type="submit" disabled={isLoading}>{isLoading ? "Guardando..." : "Guardar"}</Button>
        </DialogFooter>
      </form>
    </Form>
  );
}

// ─── Main Page ────────────────────────────────────────────────────────────────
export default function PatientDetailPage() {
  const [, params] = useRoute("/patients/:id");
  const id = params?.id ? parseInt(params.id) : 0;
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isEditing, setIsEditing] = useState(false);

  // Medication dialog state
  const [showMedCreate, setShowMedCreate] = useState(false);
  const [editingMedId, setEditingMedId] = useState<number | null>(null);

  // Attendance dialog state
  const [showAttendCreate, setShowAttendCreate] = useState(false);
  const [editingAttendId, setEditingAttendId] = useState<number | null>(null);

  const { data: patient, isLoading, isError } = useGetPatient(id, {
    query: { enabled: !!id, queryKey: getGetPatientQueryKey(id) },
  });

  const { data: programs = [] } = useListPrograms();

  const { data: medications = [] } = useListMedications(
    { patientId: id },
    { query: { enabled: !!id, queryKey: getListMedicationsQueryKey({ patientId: id }) } }
  );

  const { data: attendanceRecords = [] } = useListAttendance(
    { patientId: id },
    { query: { enabled: !!id, queryKey: getListAttendanceQueryKey({ patientId: id }) } }
  );

  const updatePatient = useUpdatePatient();
  const deletePatient = useDeletePatient();
  const createMedication = useCreateMedication();
  const updateMedication = useUpdateMedication();
  const deleteMedication = useDeleteMedication();
  const createAttendance = useCreateAttendance();
  const updateAttendance = useUpdateAttendance();
  const deleteAttendance = useDeleteAttendance();

  const editingMed = medications.find((m) => m.id === editingMedId);
  const editingAttend = attendanceRecords.find((a) => a.id === editingAttendId);

  const attendanceCount = attendanceRecords.filter((a) => a.attended).length;
  const absenceCount = attendanceRecords.filter((a) => !a.attended).length;

  const programName = patient?.programId
    ? programs.find((p) => p.id === patient.programId)?.name
    : null;

  // ── Handlers ─────────────────────────────────────────────────────────────
  const handleUpdate = (data: any) => {
    updatePatient.mutate({ id, data }, {
      onSuccess: (updated) => {
        setIsEditing(false);
        toast({ title: "Paciente actualizado correctamente." });
        queryClient.setQueryData(getGetPatientQueryKey(id), updated);
        queryClient.invalidateQueries({ queryKey: getListPatientsQueryKey() });
      },
      onError: () => toast({ title: "Error al actualizar.", variant: "destructive" }),
    });
  };

  const handleDelete = () => {
    deletePatient.mutate({ id }, {
      onSuccess: () => {
        toast({ title: "Paciente eliminado." });
        queryClient.invalidateQueries({ queryKey: getListPatientsQueryKey() });
        queryClient.invalidateQueries({ queryKey: getGetPatientsSummaryQueryKey() });
        setLocation("/patients");
      },
      onError: () => toast({ title: "Error al eliminar.", variant: "destructive" }),
    });
  };

  const handleCreateMed = (data: MedFormValues) => {
    createMedication.mutate(
      { data: { patientId: id, name: data.name, dose: data.dose, frequency: data.frequency, startDate: data.startDate ?? null, endDate: data.endDate ?? null, notes: data.notes ?? null } },
      {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: getListMedicationsQueryKey({ patientId: id }) });
          setShowMedCreate(false);
          toast({ title: "Medicamento agregado." });
        },
        onError: () => toast({ title: "Error al agregar medicamento.", variant: "destructive" }),
      }
    );
  };

  const handleUpdateMed = (data: MedFormValues) => {
    if (!editingMedId) return;
    updateMedication.mutate(
      { id: editingMedId, data: { name: data.name, dose: data.dose, frequency: data.frequency, startDate: data.startDate ?? null, endDate: data.endDate ?? null, notes: data.notes ?? null } },
      {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: getListMedicationsQueryKey({ patientId: id }) });
          setEditingMedId(null);
          toast({ title: "Medicamento actualizado." });
        },
        onError: () => toast({ title: "Error al actualizar.", variant: "destructive" }),
      }
    );
  };

  const handleDeleteMed = (medId: number) => {
    deleteMedication.mutate({ id: medId }, {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListMedicationsQueryKey({ patientId: id }) });
        toast({ title: "Medicamento eliminado." });
      },
      onError: () => toast({ title: "Error al eliminar.", variant: "destructive" }),
    });
  };

  const handleCreateAttend = (data: AttendFormValues) => {
    createAttendance.mutate(
      { data: { patientId: id, appointmentDate: data.appointmentDate, attended: data.attended, notes: data.notes ?? null } },
      {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: getListAttendanceQueryKey({ patientId: id }) });
          setShowAttendCreate(false);
          toast({ title: "Registro de asistencia guardado." });
        },
        onError: () => toast({ title: "Error al guardar asistencia.", variant: "destructive" }),
      }
    );
  };

  const handleUpdateAttend = (data: AttendFormValues) => {
    if (!editingAttendId) return;
    updateAttendance.mutate(
      { id: editingAttendId, data: { appointmentDate: data.appointmentDate, attended: data.attended, notes: data.notes ?? null } },
      {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: getListAttendanceQueryKey({ patientId: id }) });
          setEditingAttendId(null);
          toast({ title: "Asistencia actualizada." });
        },
        onError: () => toast({ title: "Error al actualizar.", variant: "destructive" }),
      }
    );
  };

  const handleDeleteAttend = (aId: number) => {
    deleteAttendance.mutate({ id: aId }, {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListAttendanceQueryKey({ patientId: id }) });
        toast({ title: "Registro eliminado." });
      },
      onError: () => toast({ title: "Error al eliminar.", variant: "destructive" }),
    });
  };

  // ── Loading / Error ───────────────────────────────────────────────────────
  if (isLoading) {
    return (
      <div className="space-y-6">
        <div className="h-8 w-32 bg-muted animate-pulse rounded" />
        <Card className="animate-pulse"><CardContent className="h-40 pt-6" /></Card>
      </div>
    );
  }

  if (isError || !patient) {
    return (
      <div className="flex flex-col items-center justify-center py-20 text-center">
        <Activity className="h-12 w-12 text-destructive mb-4 opacity-50" />
        <h2 className="text-2xl font-bold mb-2">Paciente no encontrado</h2>
        <p className="text-muted-foreground mb-6">El expediente no existe o fue eliminado.</p>
        <Link href="/patients">
          <Button variant="outline" className="gap-2">
            <ArrowLeft className="w-4 h-4" /> Volver al Directorio
          </Button>
        </Link>
      </div>
    );
  }

  if (isEditing) {
    return (
      <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-300">
        <div className="flex items-center gap-4">
          <Button variant="ghost" size="icon" onClick={() => setIsEditing(false)}>
            <ArrowLeft className="w-4 h-4" />
          </Button>
          <h1 className="text-2xl font-bold">Editar Expediente</h1>
        </div>
        <Card className="shadow-sm">
          <CardContent className="pt-6">
            <PatientForm initialData={patient} onSubmit={handleUpdate} isLoading={updatePatient.isPending} />
          </CardContent>
        </Card>
      </div>
    );
  }

  // ── View ──────────────────────────────────────────────────────────────────
  return (
    <div className="space-y-6 animate-in fade-in duration-500">
      {/* Header */}
      <div className="flex items-center justify-between">
        <Link href="/patients">
          <Button variant="ghost" size="sm" className="gap-2 text-muted-foreground hover:text-foreground">
            <ArrowLeft className="w-4 h-4" /> Directorio
          </Button>
        </Link>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" className="gap-2" onClick={() => setIsEditing(true)}>
            <Edit3 className="w-4 h-4" /> Editar
          </Button>
          <AlertDialog>
            <AlertDialogTrigger asChild>
              <Button variant="outline" size="sm" className="gap-2 text-destructive hover:bg-destructive hover:text-destructive-foreground border-destructive/30">
                <Trash2 className="w-4 h-4" /> Eliminar
              </Button>
            </AlertDialogTrigger>
            <AlertDialogContent>
              <AlertDialogHeader>
                <AlertDialogTitle>¿Eliminar paciente?</AlertDialogTitle>
                <AlertDialogDescription>
                  Se eliminará permanentemente el expediente de <strong>{patient.name}</strong> y todo su historial.
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel>Cancelar</AlertDialogCancel>
                <AlertDialogAction onClick={handleDelete} className="bg-destructive hover:bg-destructive/90">
                  Eliminar permanentemente
                </AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
        </div>
      </div>

      <div className="grid gap-6 md:grid-cols-3">
        {/* Main Info */}
        <Card className="md:col-span-2 shadow-sm border-t-4 border-t-primary">
          <CardHeader className="pb-4">
            <div className="flex justify-between items-start">
              <div>
                <h1 className="text-3xl font-bold">{patient.name}</h1>
                <p className="text-muted-foreground text-base flex items-center gap-2 mt-1">
                  <User className="w-4 h-4" /> {patient.age} años
                  {programName && (
                    <>
                      <span className="text-muted-foreground/40">·</span>
                      <ClipboardList className="w-4 h-4" /> {programName}
                    </>
                  )}
                </p>
              </div>
              <StatusBadge status={patient.status} />
            </div>
          </CardHeader>
          <CardContent className="space-y-6">
            <div>
              <h3 className="text-sm font-medium text-muted-foreground uppercase tracking-wider mb-2 flex items-center gap-2">
                <Activity className="w-4 h-4" /> Diagnóstico Principal
              </h3>
              <p className="text-lg bg-muted/30 p-4 rounded-lg border border-muted">{patient.diagnosis}</p>
            </div>
            <Separator />
            <div>
              <h3 className="text-sm font-medium text-muted-foreground uppercase tracking-wider mb-2 flex items-center gap-2">
                <FileText className="w-4 h-4" /> Notas y Observaciones
              </h3>
              {patient.notes ? (
                <div className="whitespace-pre-wrap bg-yellow-50/50 dark:bg-yellow-900/10 p-4 rounded-lg border border-yellow-100 dark:border-yellow-900/30">
                  {patient.notes}
                </div>
              ) : (
                <p className="text-muted-foreground italic p-4 rounded-lg border border-dashed text-center bg-muted/10">
                  No hay notas registradas.
                </p>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Sidebar */}
        <div className="space-y-6">
          <Card className="shadow-sm">
            <CardHeader className="bg-muted/30 pb-4">
              <CardTitle className="text-base flex items-center gap-2">
                <Calendar className="w-4 h-4 text-primary" /> Próxima Cita
              </CardTitle>
            </CardHeader>
            <CardContent className="pt-4">
              {patient.nextAppointment ? (
                <div className="text-center py-2">
                  <div className="text-2xl font-semibold text-primary mb-1">
                    {format(new Date(patient.nextAppointment), "d", { locale: es })}
                  </div>
                  <div className="text-base font-medium capitalize">
                    {format(new Date(patient.nextAppointment), "MMMM yyyy", { locale: es })}
                  </div>
                  <div className="text-sm text-muted-foreground mt-1">
                    {format(new Date(patient.nextAppointment), "EEEE", { locale: es })}
                  </div>
                </div>
              ) : (
                <div className="text-center py-4 flex flex-col items-center text-muted-foreground">
                  <Calendar className="w-8 h-8 opacity-20 mb-2" />
                  <p className="text-sm">Sin cita programada</p>
                  <Button variant="link" size="sm" className="mt-2 text-primary" onClick={() => setIsEditing(true)}>
                    Agendar cita
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>

          <Card className="shadow-sm">
            <CardHeader className="bg-muted/30 pb-4">
              <CardTitle className="text-base flex items-center gap-2">
                <Clock className="w-4 h-4 text-muted-foreground" /> Historial de Registro
              </CardTitle>
            </CardHeader>
            <CardContent className="pt-4 space-y-3 text-sm">
              <div className="flex justify-between items-center">
                <span className="text-muted-foreground">Alta en sistema:</span>
                <span className="font-medium">{format(new Date(patient.createdAt), "dd/MM/yyyy", { locale: es })}</span>
              </div>
              <Separator />
              <div className="flex justify-between items-center">
                <span className="text-muted-foreground">Ultima act.:</span>
                <span className="font-medium">{format(new Date(patient.updatedAt), "dd/MM/yyyy", { locale: es })}</span>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* ── Medications ─────────────────────────────────────────────────────── */}
      <Card className="shadow-sm">
        <CardHeader className="flex flex-row items-center justify-between pb-4">
          <CardTitle className="flex items-center gap-2">
            <Pill className="w-5 h-5 text-primary" /> Medicamentos
            {medications.length > 0 && (
              <Badge variant="secondary" className="ml-1">{medications.length}</Badge>
            )}
          </CardTitle>
          <Button size="sm" variant="outline" className="gap-2" onClick={() => setShowMedCreate(true)}>
            <Plus className="w-4 h-4" /> Agregar
          </Button>
        </CardHeader>
        <CardContent>
          {medications.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-8 text-center border border-dashed rounded-lg">
              <Pill className="w-8 h-8 text-muted-foreground/30 mb-2" />
              <p className="text-muted-foreground text-sm">No hay medicamentos registrados.</p>
              <Button variant="link" size="sm" className="mt-1" onClick={() => setShowMedCreate(true)}>
                Agregar primer medicamento
              </Button>
            </div>
          ) : (
            <div className="space-y-3">
              {medications.map((med) => (
                <div key={med.id} className="flex items-start justify-between gap-3 p-4 rounded-lg border bg-muted/10 hover:bg-muted/20 transition-colors">
                  <div className="flex items-start gap-3">
                    <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0 mt-0.5">
                      <Pill className="w-4 h-4 text-primary" />
                    </div>
                    <div>
                      <p className="font-semibold">{med.name}</p>
                      <p className="text-sm text-muted-foreground">{med.dose} · {med.frequency}</p>
                      {(med.startDate || med.endDate) && (
                        <p className="text-xs text-muted-foreground/70 mt-0.5">
                          {med.startDate && `Inicio: ${med.startDate}`}
                          {med.startDate && med.endDate && " · "}
                          {med.endDate && `Fin: ${med.endDate}`}
                        </p>
                      )}
                      {med.notes && <p className="text-xs text-muted-foreground mt-1 italic">{med.notes}</p>}
                    </div>
                  </div>
                  <div className="flex items-center gap-1 flex-shrink-0">
                    <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => setEditingMedId(med.id)}>
                      <Pencil className="w-3.5 h-3.5" />
                    </Button>
                    <AlertDialog>
                      <AlertDialogTrigger asChild>
                        <Button variant="ghost" size="icon" className="h-8 w-8 text-destructive hover:text-destructive">
                          <Trash2 className="w-3.5 h-3.5" />
                        </Button>
                      </AlertDialogTrigger>
                      <AlertDialogContent>
                        <AlertDialogHeader>
                          <AlertDialogTitle>¿Eliminar medicamento?</AlertDialogTitle>
                          <AlertDialogDescription>Se eliminara <strong>{med.name}</strong> del expediente.</AlertDialogDescription>
                        </AlertDialogHeader>
                        <AlertDialogFooter>
                          <AlertDialogCancel>Cancelar</AlertDialogCancel>
                          <AlertDialogAction onClick={() => handleDeleteMed(med.id)} className="bg-destructive hover:bg-destructive/90">Eliminar</AlertDialogAction>
                        </AlertDialogFooter>
                      </AlertDialogContent>
                    </AlertDialog>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* ── Attendance ───────────────────────────────────────────────────────── */}
      <Card className="shadow-sm">
        <CardHeader className="flex flex-row items-center justify-between pb-4">
          <div className="flex items-center gap-3">
            <CardTitle className="flex items-center gap-2">
              <Calendar className="w-5 h-5 text-primary" /> Asistencia
            </CardTitle>
            {attendanceRecords.length > 0 && (
              <div className="flex gap-2">
                <Badge variant="outline" className="border-emerald-300 text-emerald-700 bg-emerald-50 gap-1">
                  <CheckCircle2 className="w-3 h-3" /> {attendanceCount}
                </Badge>
                <Badge variant="outline" className={`gap-1 ${absenceCount > 0 ? "border-amber-300 text-amber-700 bg-amber-50" : "border-muted text-muted-foreground"}`}>
                  <XCircle className="w-3 h-3" /> {absenceCount}
                </Badge>
              </div>
            )}
          </div>
          <Button size="sm" variant="outline" className="gap-2" onClick={() => setShowAttendCreate(true)}>
            <Plus className="w-4 h-4" /> Registrar
          </Button>
        </CardHeader>
        <CardContent>
          {attendanceRecords.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-8 text-center border border-dashed rounded-lg">
              <Calendar className="w-8 h-8 text-muted-foreground/30 mb-2" />
              <p className="text-muted-foreground text-sm">No hay registros de asistencia.</p>
              <Button variant="link" size="sm" className="mt-1" onClick={() => setShowAttendCreate(true)}>
                Registrar primera asistencia
              </Button>
            </div>
          ) : (
            <div className="space-y-2">
              {[...attendanceRecords]
                .sort((a, b) => b.appointmentDate.localeCompare(a.appointmentDate))
                .map((rec) => (
                  <div
                    key={rec.id}
                    className={`flex items-center justify-between gap-3 p-3 rounded-lg border transition-colors ${
                      !rec.attended
                        ? "bg-amber-50/60 border-amber-200 dark:bg-amber-900/10 dark:border-amber-800"
                        : "bg-muted/10 hover:bg-muted/20"
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      {rec.attended ? (
                        <CheckCircle2 className="w-5 h-5 text-emerald-500 flex-shrink-0" />
                      ) : (
                        <XCircle className="w-5 h-5 text-amber-500 flex-shrink-0" />
                      )}
                      <div>
                        <p className="font-medium text-sm">{rec.appointmentDate}</p>
                        {rec.notes && <p className="text-xs text-muted-foreground">{rec.notes}</p>}
                        {!rec.attended && (
                          <p className="text-xs font-medium text-amber-600 mt-0.5">Ausente — recordatorio pendiente</p>
                        )}
                      </div>
                    </div>
                    <div className="flex items-center gap-1 flex-shrink-0">
                      <Badge variant={rec.attended ? "outline" : "secondary"} className={rec.attended ? "border-emerald-300 text-emerald-700 text-xs" : "bg-amber-100 text-amber-700 text-xs"}>
                        {rec.attended ? "Asistio" : "No asistio"}
                      </Badge>
                      <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => setEditingAttendId(rec.id)}>
                        <Pencil className="w-3 h-3" />
                      </Button>
                      <AlertDialog>
                        <AlertDialogTrigger asChild>
                          <Button variant="ghost" size="icon" className="h-7 w-7 text-destructive hover:text-destructive">
                            <Trash2 className="w-3 h-3" />
                          </Button>
                        </AlertDialogTrigger>
                        <AlertDialogContent>
                          <AlertDialogHeader>
                            <AlertDialogTitle>¿Eliminar registro?</AlertDialogTitle>
                            <AlertDialogDescription>Se eliminara el registro del {rec.appointmentDate}.</AlertDialogDescription>
                          </AlertDialogHeader>
                          <AlertDialogFooter>
                            <AlertDialogCancel>Cancelar</AlertDialogCancel>
                            <AlertDialogAction onClick={() => handleDeleteAttend(rec.id)} className="bg-destructive hover:bg-destructive/90">Eliminar</AlertDialogAction>
                          </AlertDialogFooter>
                        </AlertDialogContent>
                      </AlertDialog>
                    </div>
                  </div>
                ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Dialogs */}
      <Dialog open={showMedCreate} onOpenChange={setShowMedCreate}>
        <DialogContent>
          <DialogHeader><DialogTitle>Agregar Medicamento</DialogTitle></DialogHeader>
          <MedicationForm onSubmit={handleCreateMed} isLoading={createMedication.isPending} />
        </DialogContent>
      </Dialog>

      <Dialog open={!!editingMedId} onOpenChange={(o) => !o && setEditingMedId(null)}>
        <DialogContent>
          <DialogHeader><DialogTitle>Editar Medicamento</DialogTitle></DialogHeader>
          {editingMed && (
            <MedicationForm
              initialData={{ name: editingMed.name, dose: editingMed.dose, frequency: editingMed.frequency, startDate: editingMed.startDate, endDate: editingMed.endDate, notes: editingMed.notes }}
              onSubmit={handleUpdateMed}
              isLoading={updateMedication.isPending}
            />
          )}
        </DialogContent>
      </Dialog>

      <Dialog open={showAttendCreate} onOpenChange={setShowAttendCreate}>
        <DialogContent>
          <DialogHeader><DialogTitle>Registrar Asistencia</DialogTitle></DialogHeader>
          <AttendanceForm onSubmit={handleCreateAttend} isLoading={createAttendance.isPending} />
        </DialogContent>
      </Dialog>

      <Dialog open={!!editingAttendId} onOpenChange={(o) => !o && setEditingAttendId(null)}>
        <DialogContent>
          <DialogHeader><DialogTitle>Editar Registro</DialogTitle></DialogHeader>
          {editingAttend && (
            <AttendanceForm
              initialData={{ appointmentDate: editingAttend.appointmentDate, attended: editingAttend.attended, notes: editingAttend.notes }}
              onSubmit={handleUpdateAttend}
              isLoading={updateAttendance.isPending}
            />
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
