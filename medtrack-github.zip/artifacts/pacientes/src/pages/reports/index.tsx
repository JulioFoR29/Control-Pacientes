import { useState } from "react";
import {
  useGetMonthlyReport,
  getGetMonthlyReportQueryKey,
} from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { FileBarChart, Download, Users, CalendarCheck, CalendarX, AlertCircle } from "lucide-react";
import * as XLSX from "xlsx";

const MONTHS = [
  { value: 1, label: "Enero" },
  { value: 2, label: "Febrero" },
  { value: 3, label: "Marzo" },
  { value: 4, label: "Abril" },
  { value: 5, label: "Mayo" },
  { value: 6, label: "Junio" },
  { value: 7, label: "Julio" },
  { value: 8, label: "Agosto" },
  { value: 9, label: "Septiembre" },
  { value: 10, label: "Octubre" },
  { value: 11, label: "Noviembre" },
  { value: 12, label: "Diciembre" },
];

const currentDate = new Date();

export default function ReportsPage() {
  const [month, setMonth] = useState(currentDate.getMonth() + 1);
  const [year, setYear] = useState(currentDate.getFullYear());

  const { data: report, isLoading, isError } = useGetMonthlyReport(
    { month, year },
    {
      query: {
        queryKey: getGetMonthlyReportQueryKey({ month, year }),
        enabled: true,
      },
    }
  );

  const handleExportExcel = () => {
    if (!report) return;

    const monthLabel = MONTHS.find((m) => m.value === report.month)?.label || "";

    const summaryRows = [
      ["INFORME MENSUAL DE PACIENTES"],
      [`Período: ${monthLabel} ${report.year}`],
      [`Fecha de corte: ${report.cutoffDate}`],
      [],
      ["RESUMEN"],
      ["Total Pacientes", report.totalPatients],
      ["Total Asistencias", report.totalAttendances],
      ["Total Ausencias", report.totalAbsences],
      [],
    ];

    const headerRow = [
      "Nombre",
      "Edad",
      "Diagnóstico",
      "Estado",
      "Programa",
      "Asistencias",
      "Ausencias",
      "Medicamentos",
    ];

    const dataRows = report.patients.map((p) => [
      p.name,
      p.age,
      p.diagnosis,
      p.status === "active" ? "Activo" : p.status === "discharged" ? "Alta" : "Pendiente",
      p.programName || "-",
      p.attendanceCount,
      p.absenceCount,
      p.medications.join("; ") || "-",
    ]);

    const wb = XLSX.utils.book_new();
    const wsData = [...summaryRows, headerRow, ...dataRows];
    const ws = XLSX.utils.aoa_to_sheet(wsData);

    // Column widths
    ws["!cols"] = [
      { wch: 30 }, { wch: 8 }, { wch: 25 }, { wch: 12 },
      { wch: 20 }, { wch: 12 }, { wch: 12 }, { wch: 50 },
    ];

    XLSX.utils.book_append_sheet(wb, ws, "Informe");
    XLSX.writeFile(wb, `Informe_${monthLabel}_${report.year}.xlsx`);
  };

  const years = Array.from({ length: 5 }, (_, i) => currentDate.getFullYear() - 2 + i);
  const monthLabel = MONTHS.find((m) => m.value === month)?.label || "";

  return (
    <div className="space-y-6 animate-in fade-in duration-500">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Informes Mensuales</h1>
          <p className="text-muted-foreground mt-1">
            Informe con fecha de corte el 25 de cada mes.
          </p>
        </div>
        <Button
          onClick={handleExportExcel}
          disabled={!report || isLoading}
          className="gap-2 self-start sm:self-auto"
        >
          <Download className="w-4 h-4" />
          Exportar a Excel
        </Button>
      </div>

      {/* Period Selector */}
      <Card className="shadow-sm">
        <CardContent className="pt-6">
          <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4">
            <span className="text-sm font-medium text-muted-foreground whitespace-nowrap">Seleccionar periodo:</span>
            <div className="flex gap-3 flex-wrap">
              <Select value={String(month)} onValueChange={(v) => setMonth(Number(v))}>
                <SelectTrigger className="w-40">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {MONTHS.map((m) => (
                    <SelectItem key={m.value} value={String(m.value)}>
                      {m.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Select value={String(year)} onValueChange={(v) => setYear(Number(v))}>
                <SelectTrigger className="w-28">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {years.map((y) => (
                    <SelectItem key={y} value={String(y)}>
                      {y}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            {report && (
              <span className="text-sm text-muted-foreground sm:ml-auto">
                Fecha de corte: <strong>{report.cutoffDate}</strong>
              </span>
            )}
          </div>
        </CardContent>
      </Card>

      {isLoading && (
        <div className="grid gap-4 md:grid-cols-3">
          {[1, 2, 3].map((i) => (
            <Card key={i} className="animate-pulse">
              <CardContent className="pt-6">
                <div className="h-8 bg-muted rounded w-1/3 mb-2" />
                <div className="h-4 bg-muted rounded w-1/2" />
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {isError && (
        <Card className="border-destructive/30">
          <CardContent className="flex items-center gap-3 py-6">
            <AlertCircle className="w-5 h-5 text-destructive flex-shrink-0" />
            <p className="text-destructive">No se pudo cargar el informe. Intenta nuevamente.</p>
          </CardContent>
        </Card>
      )}

      {report && !isLoading && (
        <>
          {/* Summary Cards */}
          <div className="grid gap-4 md:grid-cols-3">
            <Card className="shadow-sm border-t-4 border-t-primary">
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">Total Pacientes</p>
                    <p className="text-4xl font-bold mt-1">{report.totalPatients}</p>
                  </div>
                  <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center">
                    <Users className="w-6 h-6 text-primary" />
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card className="shadow-sm border-t-4 border-t-emerald-500">
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">Total Asistencias</p>
                    <p className="text-4xl font-bold mt-1 text-emerald-600">{report.totalAttendances}</p>
                  </div>
                  <div className="w-12 h-12 rounded-xl bg-emerald-100 flex items-center justify-center">
                    <CalendarCheck className="w-6 h-6 text-emerald-600" />
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card className="shadow-sm border-t-4 border-t-amber-500">
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">Total Ausencias</p>
                    <p className="text-4xl font-bold mt-1 text-amber-600">{report.totalAbsences}</p>
                  </div>
                  <div className="w-12 h-12 rounded-xl bg-amber-100 flex items-center justify-center">
                    <CalendarX className="w-6 h-6 text-amber-600" />
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Patient Table */}
          <Card className="shadow-sm">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileBarChart className="w-5 h-5 text-primary" />
                Detalle por Paciente — {monthLabel} {report.year}
              </CardTitle>
            </CardHeader>
            <CardContent className="p-0">
              {report.patients.length === 0 ? (
                <div className="flex flex-col items-center justify-center py-16 text-center px-4">
                  <FileBarChart className="w-10 h-10 text-muted-foreground/30 mb-3" />
                  <p className="text-muted-foreground">No hay pacientes registrados para este periodo.</p>
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="border-b bg-muted/40">
                        <th className="text-left px-6 py-3 font-medium text-muted-foreground">Paciente</th>
                        <th className="text-left px-4 py-3 font-medium text-muted-foreground">Estado</th>
                        <th className="text-left px-4 py-3 font-medium text-muted-foreground">Programa</th>
                        <th className="text-center px-4 py-3 font-medium text-muted-foreground">Asistencias</th>
                        <th className="text-center px-4 py-3 font-medium text-muted-foreground">Ausencias</th>
                        <th className="text-left px-4 py-3 font-medium text-muted-foreground">Medicamentos</th>
                      </tr>
                    </thead>
                    <tbody>
                      {report.patients.map((patient, idx) => (
                        <tr
                          key={patient.id}
                          className={`border-b last:border-0 transition-colors hover:bg-muted/20 ${
                            patient.absenceCount > 0 && patient.attendanceCount === 0
                              ? "bg-amber-50/50 dark:bg-amber-900/10"
                              : ""
                          }`}
                        >
                          <td className="px-6 py-4">
                            <div className="font-medium">{patient.name}</div>
                            <div className="text-muted-foreground text-xs">{patient.age} años · {patient.diagnosis}</div>
                          </td>
                          <td className="px-4 py-4">
                            <Badge
                              variant="outline"
                              className={
                                patient.status === "active"
                                  ? "border-emerald-300 text-emerald-700 bg-emerald-50"
                                  : patient.status === "pending"
                                  ? "border-amber-300 text-amber-700 bg-amber-50"
                                  : "border-slate-300 text-slate-600 bg-slate-50"
                              }
                            >
                              {patient.status === "active" ? "Activo" : patient.status === "pending" ? "Pendiente" : "Alta"}
                            </Badge>
                          </td>
                          <td className="px-4 py-4 text-muted-foreground">
                            {patient.programName || <span className="italic text-muted-foreground/50">Sin programa</span>}
                          </td>
                          <td className="px-4 py-4 text-center">
                            <span className="inline-flex items-center justify-center w-8 h-8 rounded-full bg-emerald-100 text-emerald-700 font-semibold text-sm">
                              {patient.attendanceCount}
                            </span>
                          </td>
                          <td className="px-4 py-4 text-center">
                            <span className={`inline-flex items-center justify-center w-8 h-8 rounded-full font-semibold text-sm ${
                              patient.absenceCount > 0
                                ? "bg-amber-100 text-amber-700"
                                : "bg-muted text-muted-foreground"
                            }`}>
                              {patient.absenceCount}
                            </span>
                          </td>
                          <td className="px-4 py-4 text-muted-foreground max-w-xs">
                            {patient.medications.length > 0 ? (
                              <div className="flex flex-wrap gap-1">
                                {patient.medications.map((med, i) => (
                                  <Badge key={i} variant="secondary" className="text-xs font-normal">
                                    {med}
                                  </Badge>
                                ))}
                              </div>
                            ) : (
                              <span className="italic text-muted-foreground/50">Sin medicamentos</span>
                            )}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </CardContent>
          </Card>
        </>
      )}
    </div>
  );
}
