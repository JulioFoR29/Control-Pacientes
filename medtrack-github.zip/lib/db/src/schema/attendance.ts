import { pgTable, serial, text, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { patientsTable } from "./patients";

export const attendanceTable = pgTable("attendance", {
  id: serial("id").primaryKey(),
  patientId: integer("patient_id").notNull().references(() => patientsTable.id, { onDelete: "cascade" }),
  appointmentDate: text("appointment_date").notNull(),
  attended: boolean("attended").notNull().default(false),
  contacted: boolean("contacted").notNull().default(false),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export type AttendanceRecord = typeof attendanceTable.$inferSelect;
