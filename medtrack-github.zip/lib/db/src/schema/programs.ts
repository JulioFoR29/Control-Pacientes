import { pgTable, serial, text, timestamp } from "drizzle-orm/pg-core";

export const programsTable = pgTable("programs", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export type Program = typeof programsTable.$inferSelect;
